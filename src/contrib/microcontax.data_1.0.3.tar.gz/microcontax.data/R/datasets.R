#' @name contax.full
#' @aliases microcontax.data
#' @docType data
#' @title The ConTax data set
#'
#' @description The full version of the ConTax data set.
#'
#' @usage
#' data(contax.full)
#'
#' @details
#' The \code{contax.full} is the full consensus taxonomy data set as described in Vinje et al. (2016). The data
#' set is too large for CRAN and thus available as a separate package \code{microcontax.data}.
#' It is a \code{\link[microseq]{Fasta}} object containing 664,199 sequences.
#'
#' The Header of every sequence starts with a unique tag, in this case the text "ConTax" and some integer.
#' This is followed by a token describing the origin of the sequence. It is typically
#'
#' "Intersection=SRG"
#'
#' meaning it is found in both the Silva, RDP and Greengenes data repository. Intersections can also be
#' SR, SG and RG if the sequence was found in two repositories only. The taxonomy information for each
#' sequence is found in the third token. It follows a commonly used format:
#'
#' "k__<...>;p__<...>;c__<...>;o__<...>;f__<...>;g__<...>;"
#'
#' where <...> is some proper text. The letters, followed by a double underscore, refer to the taxonomic levels
#' Domain (Kingdom), Phylum, Class, Order, Family and Genus.
#' Here is an example of a proper string:
#'
#' "k__Bacteria;p__Firmicutes;c__Bacilli;o__Bacillales;f__Staphylococcaceae;g__Staphylococcus;"
#'
#' As long as this format is used, the taxonomy information can be extracted by the
#' extractor-functions \code{\link[microcontax]{getDomain}}, \code{\link[microcontax]{getPhylum}},...,\code{\link[microcontax]{getGenus}}
#' supplied by the \code{\link{microcontax}} package.
#'
#'
#' @author Hilde Vinje, Kristian Hovde Liland, Lars Snipen.
#'
#' @seealso \code{\link[microcontax]{contax.trim}}, \code{\link[microcontax]{medoids}}, \code{\link[microcontax]{getDomain}}.
#'
#' @examples
#' \dontrun{
#' # Attach data set and check dimensions:
#' data(contax.full)
#' dim(contax.full)
#'
#' # Write to FASTA-file
#' writeFasta(contax.full,out.file="ConTax_full.fasta")
#' }
#'
NULL
